export interface Trophy {
  id: string;
  plateNumber: string;
  imageUrl: string;
  createdAt: number;
  userId: string;
  number: number;
  isNotFormat: boolean;
  numberNotFormat?: string;
  location?: {
    lat: number;
    lng: number;
  };
}