import { useContext } from 'react';
import { AuthContext, type AuthContextType } from '../context/AuthContextValue';

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === null) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};