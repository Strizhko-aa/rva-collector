import { Outlet, Link } from 'react-router-dom';
import { Bage } from '../components/Bage';
import { useAuth } from '../hooks/useAuth';

const isHaveNewNotifications = true; // TODO: Replace with real notification logic

const showBage = () => {
  if (isHaveNewNotifications) {
    return <Bage text="new" color="green" offset={{ top: -37, left: 26 }} />;
  }
  return null;
}

const MainLayout = () => {
  const user = useAuth().user; // TODO: Use auth context to determine if user is logged in and has notifications

  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-white shadow-sm p-4">
        <nav className="max-w-4xl mx-auto flex justify-between items-center">
          <Link title="PBA Collector" to="/" className="text-xl font-bold text-blue-600">
            📸 PBA Collector
          </Link>
          <div className="space-x-4">
            <Link to="/" className="hover:text-blue-500">Лента</Link>
            {
              user ? 
                <Link to="/profile" className="hover:text-blue-500 relative">
                  Профиль { showBage() }
                </Link>
              : "Войти"
            }
          </div>
        </nav>
      </header>

      <main className="flex-grow max-w-4xl mx-auto w-full p-4">
        <Outlet /> 
      </main>

      <footer className="p-4 text-center text-gray-500 text-sm">
        © 2026 PBA Collector
      </footer>
    </div>
  );
};

export default MainLayout;